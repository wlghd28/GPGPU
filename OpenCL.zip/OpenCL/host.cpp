#include <stdio.h>
#include <stdlib.h>
#include <CL/cl.h>
#include <Windows.h>
#include <string.h>
#include <tchar.h>
#include <stdbool.h>

#include "deviceInfo.h"
// BMP �̹����� �ҷ����� ���� �۾�
#pragma warning(disable : 4996)
#pragma pack(push, 1)
struct Bitmapfileheader
{
	short int bmptype;
	int bfsize;
	short int bfreserved1, bfreserved2;
	int bfoffbits;
}bfh;
struct Bitmapinfoheader
{
	int bisize, biwidth, biheight;
	short int biplanes, bibitcount;
	int compression, sizeimage, xpelspermeter, ypelspermeter, biclrused, biclrimportant;
}bih;
struct Palette {
	unsigned char blue;
	unsigned char green;
	unsigned char red;
}rgb;
#pragma pack(pop)	


int bihwidth;		// �̹��� ���� ������
int bihheight;		// �̹��� ���� ������ (line ��)

// kernel�� �о char pointer����
char* readSource(char* kernelPath) {

	cl_int status;
	FILE *fp;
	char *source;
	long int size;

	printf("Program file is: %s\n", kernelPath);

	fp = fopen(kernelPath, "rb");
	if (!fp) {
		printf("Could not open kernel file\n");
		exit(-1);
	}
	status = fseek(fp, 0, SEEK_END);
	if (status != 0) {
		printf("Error seeking to end of file\n");
		exit(-1);
	}
	size = ftell(fp);
	if (size < 0) {
		printf("Error getting file position\n");
		exit(-1);
	}

	rewind(fp);

	source = (char *)malloc(size + 1);

	int i;
	for (i = 0; i < size + 1; i++) {
		source[i] = '\0';
	}

	if (source == NULL) {
		printf("Error allocating space for the kernel source\n");
		exit(-1);
	}

	fread(source, 1, size, fp);
	source[size] = '\0';

	return source;
}

//����̽� init, Ŀ�� ����
void CLInit()
{
	int i, j;
	char * value;
	size_t valueSize;
	cl_uint platformCount;
	cl_platform_id * platforms;
	cl_uint deviceCount;
	cl_device_id * devices;
	cl_uint maxComputeUnits;

	// get all platforms
	clGetPlatformIDs(0, NULL, &platformCount);
	platforms = (cl_platform_id *)malloc(sizeof(cl_platform_id) * platformCount);
	clGetPlatformIDs(platformCount, platforms, NULL);

	for (i = 0; i < platformCount; i++) {

		// get all devices
		clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, 0, NULL, &deviceCount);
		devices = (cl_device_id *)malloc(sizeof(cl_device_id) * deviceCount);
		clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, deviceCount, devices, NULL);

		// for each device print critical attributes
		for (j = 0; j < deviceCount; j++) {

			// print device name
			clGetDeviceInfo(devices[j], CL_DEVICE_NAME, 0, NULL, &valueSize);
			value = (char *)malloc(valueSize);
			clGetDeviceInfo(devices[j], CL_DEVICE_NAME, valueSize, value, NULL);
			printf("platform %d. Device %d: %s\n", i + 1, j + 1, value);
			free(value);
			
			// print hardware device version
			clGetDeviceInfo(devices[j], CL_DEVICE_VERSION, 0, NULL, &valueSize);
			value = (char *)malloc(valueSize);
			clGetDeviceInfo(devices[j], CL_DEVICE_VERSION, valueSize, value, NULL);
			printf(" %d.%d Hardware version: %s\n", i + 1, 1, value);
			free(value);

			// print software driver version
			clGetDeviceInfo(devices[j], CL_DRIVER_VERSION, 0, NULL, &valueSize);
			value = (char *)malloc(valueSize);
			clGetDeviceInfo(devices[j], CL_DRIVER_VERSION, valueSize, value, NULL);
			printf(" %d.%d Software version: %s\n", i + 1, 2, value);
			free(value);

			// print c version supported by compiler for device
			clGetDeviceInfo(devices[j], CL_DEVICE_OPENCL_C_VERSION, 0, NULL, &valueSize);
			value = (char*)malloc(valueSize);
			clGetDeviceInfo(devices[j], CL_DEVICE_OPENCL_C_VERSION, valueSize, value, NULL);
			printf(" %d.%d OpenCL C version: %s\n", i + 1, 3, value);
			free(value);

			// print parallel compute units
			clGetDeviceInfo(devices[j], CL_DEVICE_MAX_COMPUTE_UNITS,
				sizeof(maxComputeUnits), &maxComputeUnits, NULL);
			printf(" %d.%d Parallel compute units: %d\n", i + 1, 4, maxComputeUnits);
		}
	}
	int platformNum;
	int deviceNum;
	printf("\n\nSELECT PLATFORM('1' ~ '%d') : ", platformCount);
	scanf("%d", &platformNum);
	printf("\n");
	printf("SELECT DEVICE('1' ~ '%d') : ", deviceCount);
	scanf("%d", &deviceNum);
	printf("\n");
	clGetDeviceIDs(platforms[platformNum - 1], CL_DEVICE_TYPE_ALL, deviceCount, devices, NULL);

	device = devices[deviceNum - 1];

	//create context
	context = clCreateContext(NULL, 1, &device, NULL, NULL, NULL);

	//create command queue
	queue = clCreateCommandQueue(context, device, 0, NULL);

	// �ؽ�Ʈ���Ϸκ��� ���α׷� �б�
	char * source = readSource("convolution.cl");

	// compile program
	program = clCreateProgramWithSource(context, 1,
		(const char **)&source, NULL, NULL);
	cl_int build_status;
	build_status = clBuildProgram(program, 1, &device, NULL, NULL,
		NULL);

	//Ŀ�� ������ ����
	simpleKernel = clCreateKernel(program, "simpleKernel", NULL);

}

//���ۻ��� �� write
void bufferWrite()
{

	FILE * fp_A;
	FILE * fp_B;
	struct Bitmapfileheader bfh;
	struct Bitmapinfoheader bih;
	struct Palette rgb1, rgb2;

	fp_A = fopen("background.bmp", "rb");
	fp_B = fopen("background2.bmp", "rb");
	if (fp_A == NULL || fp_B == NULL)
	{
		printf("file not found");
		getchar();
		exit(0);
	}
	fread(&bfh, sizeof(bfh), 1, fp_A);
	fread(&bih, sizeof(bih), 1, fp_A);

	bihwidth = ((bih.biwidth + 3) / 4) * 4;
	bihheight = bih.biheight;

	// �޸� ���� ����

	d_red_A = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);
	d_green_A = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);
	d_blue_A = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);
	d_red_B = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);
	d_green_B = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);
	d_blue_B = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);
	d_red_output = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);
	d_green_output = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);
	d_blue_output = clCreateBuffer(context, CL_MEM_READ_WRITE,
		bihwidth * bihheight * sizeof(unsigned char), NULL, NULL);


	unsigned char* red_A = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);
	unsigned char* green_A = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);
	unsigned char* blue_A = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);
	unsigned char* red_B = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);
	unsigned char* green_B = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);
	unsigned char* blue_B = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);

	
	for (int i = 0; i < bihwidth * bihheight; i++) {
		fread(&rgb1, 4, 1, fp_A);
		fread(&rgb2, 4, 1, fp_B);
		red_A[i] = rgb1.red;
		green_A[i] = rgb1.green;
		blue_A[i] = rgb1.blue;

		red_B[i] = rgb2.red;
		green_B[i] = rgb2.green;
		blue_B[i] = rgb2.blue;
	}

	
	clEnqueueWriteBuffer(queue, d_red_A, CL_TRUE, 0, sizeof(unsigned char) * bihwidth * bihheight,
		red_A, 0, NULL, NULL);
	clEnqueueWriteBuffer(queue, d_green_A, CL_TRUE, 0, sizeof(unsigned char) * bihwidth * bihheight,
		green_A, 0, NULL, NULL);
	clEnqueueWriteBuffer(queue, d_blue_A, CL_TRUE, 0, sizeof(unsigned char) * bihwidth * bihheight,
		blue_A, 0, NULL, NULL);
	clEnqueueWriteBuffer(queue, d_red_B, CL_TRUE, 0, sizeof(unsigned char) * bihwidth * bihheight,
		red_B, 0, NULL, NULL);
	clEnqueueWriteBuffer(queue, d_green_B, CL_TRUE, 0, sizeof(unsigned char) * bihwidth * bihheight,
		green_B, 0, NULL, NULL);
	clEnqueueWriteBuffer(queue, d_blue_B, CL_TRUE, 0, sizeof(unsigned char) * bihwidth * bihheight,
		blue_B, 0, NULL, NULL);

	free(red_A);
	free(green_A);
	free(blue_A);
	free(red_B);
	free(green_B);
	free(blue_B);

	fclose(fp_A);
	fclose(fp_B);
}

void runKernel()
{
	int totalWorkItemsX = bihwidth * bihheight;
	int totalWorkItemsY = 1;

	size_t globalSize[2] = { totalWorkItemsX, totalWorkItemsY };
	//float *minVal, *maxVal;

	// Ŀ�� �Ű����� ���� 
	clSetKernelArg(simpleKernel, 0, sizeof(cl_mem), &d_red_A);
	clSetKernelArg(simpleKernel, 1, sizeof(cl_mem), &d_green_A);
	clSetKernelArg(simpleKernel, 2, sizeof(cl_mem), &d_blue_A);
	clSetKernelArg(simpleKernel, 3, sizeof(cl_mem), &d_red_B);
	clSetKernelArg(simpleKernel, 4, sizeof(cl_mem), &d_green_B);
	clSetKernelArg(simpleKernel, 5, sizeof(cl_mem), &d_blue_B);
	clSetKernelArg(simpleKernel, 6, sizeof(cl_mem), &d_red_output);
	clSetKernelArg(simpleKernel, 7, sizeof(cl_mem), &d_green_output);
	clSetKernelArg(simpleKernel, 8, sizeof(cl_mem), &d_blue_output);

	clEnqueueNDRangeKernel(queue, simpleKernel, 2, NULL, globalSize,
		NULL, 0, NULL, NULL);
	// �Ϸ� ��� 
	clFinish(queue);
	

	unsigned char* red_output = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);
	unsigned char* green_output = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);
	unsigned char* blue_output = (unsigned char*)malloc(sizeof(unsigned char) * bihwidth * bihheight);

	clEnqueueReadBuffer(queue, d_red_output, CL_TRUE, 0,
		bihwidth * bihheight * sizeof(unsigned char), red_output, 0, NULL, NULL);
	clEnqueueReadBuffer(queue, d_green_output, CL_TRUE, 0,
		bihwidth * bihheight * sizeof(unsigned char), green_output, 0, NULL, NULL);
	clEnqueueReadBuffer(queue, d_blue_output, CL_TRUE, 0,
		bihwidth * bihheight * sizeof(unsigned char), blue_output, 0, NULL, NULL);
	
	/*
	int index = 0;
	HDC hdc;
	hdc = GetDC(NULL);
	for (int i = 0; i < bihheight; i++)
	{
		for (int j = 0; j < bihwidth; j++)
		{
			SetPixel(hdc, j, bihheight - i - 1, RGB(red_output[index], green_output[index], blue_output[index]));
			index++;
		}
	}
	ReleaseDC(NULL, hdc);
	*/

	free(red_output);
	free(green_output);
	free(blue_output);
}

void Release()
{
	// ������
	clReleaseProgram(program);
	clReleaseCommandQueue(queue);
	clReleaseContext(context);
}
void CpuCal(long int size) {

	FILE* fp_A;
	FILE* fp_B;
	struct Bitmapfileheader bfh;
	struct Bitmapinfoheader bih;
	struct Palette* rgb1;
	struct Palette* rgb2;
	struct Palette* outputArray;

	fp_A = fopen("background.bmp", "rb");
	fp_B = fopen("background2.bmp", "rb");

	if (fp_A == NULL)
	{
		printf("file not found");
		getchar();
		exit(0);
	}
	if (fp_B == NULL)
	{
		printf("file not found");
		getchar();
		exit(0);
	}
	fread(&bfh, sizeof(bfh), 1, fp_A);
	fread(&bih, sizeof(bih), 1, fp_A);

	bihwidth = ((bih.biwidth + 3) / 4) * 4;
	bihheight = bih.biheight;

	rgb1 = (struct Palette*)malloc(sizeof(struct Palette) * bihwidth * bihheight);
	rgb2 = (struct Palette*)malloc(sizeof(struct Palette) * bihwidth * bihheight);
	outputArray = (struct Palette*)malloc(sizeof(struct Palette) * bihwidth * bihheight);

	for (int i = 0; i < bihwidth * bihheight; i++)
	{
		fread(&rgb1[i], 4, 1, fp_A);
		fread(&rgb2[i], 4, 1, fp_B);
	}

	for (int i = 0; i < size; i++) {
		for (int i = 0; i < bihwidth * bihheight; i++)
		{
			outputArray[i].red = (rgb1[i].red * i / (bihwidth * bihheight)) + (rgb2[i].red * i / (bihwidth * bihheight));
			outputArray[i].green = (rgb1[i].green * i / (bihwidth * bihheight)) + (rgb2[i].green * i / (bihwidth * bihheight));
			outputArray[i].blue = (rgb1[i].blue * i / (bihwidth * bihheight)) + (rgb2[i].blue * i / (bihwidth * bihheight));
		}
	}

	/*
	int index = 0;
	HDC hdc;
	hdc = GetDC(NULL);
	for (int i = 0; i< bihheight; i++)
	{
		for (int j = 0; j < bihwidth; j++)
		{
			SetPixel(hdc, j, bihheight - i - 1, RGB(outputArray[index].red, outputArray[index].green, outputArray[index].blue));
			index++;
		}
	}
	ReleaseDC(NULL, hdc);
	*/
	free(rgb1);
	free(rgb2);
	free(outputArray);

	fclose(fp_A);
	fclose(fp_B);

}

int main(int argc, char** argv) {

	long int data_size;	// ������ �� ����
	long int i = 0;		// �ݺ��� ����

	printf("������ ������ �� �Է� : ");
	scanf("%d", &data_size);

	QueryPerformanceFrequency(&tot_clockFreq);

	// OpenCL ����̽�, Ŀ�� �¾�
	CLInit();
	
	QueryPerformanceCounter(&tot_beginClock); //�ð����� ����

	//����̽� �� ���� ���� �� write								 
	bufferWrite();

	for (i = 0; i < data_size; i++) {
		//Ŀ�� ����
		runKernel();
	}

	QueryPerformanceCounter(&tot_endClock);
	double totalTime = (double)(tot_endClock.QuadPart - tot_beginClock.QuadPart) / tot_clockFreq.QuadPart;
	printf("Total processing Time_GPU : %f ms\n", totalTime * 1000);

	Release();

	printf("\n");

	// CPU ����
	QueryPerformanceCounter(&tot_beginClock); //�ð����� ����

	//CPU ����
	CpuCal(data_size);

	QueryPerformanceCounter(&tot_endClock);
	double totalTime2 = (double)(tot_endClock.QuadPart - tot_beginClock.QuadPart) / tot_clockFreq.QuadPart;
	printf("Total processing Time_CPU : %f ms\n", totalTime2 * 1000);

	system("pause");

	return 0;
}
