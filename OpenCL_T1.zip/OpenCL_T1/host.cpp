#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include <process.h>
#include "deviceInfo.h"
//#include "resource.h"

// ����ũ�� �迭
short mask[75];

double total_Time_CPU = 0;
double total_Time_GPU = 0;
LARGE_INTEGER beginClock, endClock, clockFreq;
LARGE_INTEGER tot_beginClock, tot_endClock, tot_clockFreq;

unsigned char* pix;
unsigned char* b_pix;

BITMAPFILEHEADER bfh;
BITMAPINFOHEADER bih;
BITMAPFILEHEADER b_bfh;
BITMAPINFOHEADER b_bih;


// �̹��� ������ �ٷ�� ���� ����ϴ� ����
int channel = 5;
int bpl, b_bpl;
int bpl_size, b_bpl_size;
int width, height, b_width, b_height;
int m_width, b_m_width;
int pix_size;
int b_pix_size;	// 5 X 5�� ��ŭ ������ �̹��� ������
int pad, b_pad;		// �е� �޸� ������
BYTE trash[3] = { 0 };		// �е� �޸�

void MaskAlloc();			// ����ũ �� �Ҵ�
//char str[100];
char str_Extend[100];
void Fwrite_Extend(char * fn);		// ����� �ȼ����� bmp���Ϸ� �����Ѵ�
//void Fwrite(char * fn);
//void Draw();				// pix �����͸� ȭ������ ���
//void b_Draw();				// b_pix �����͸� ȭ������ ���
void MultiColor();			// ��ƼĮ�� ����

// OpenCL ���� �Լ�
char* readSource(char* kernelPath);
void CLInit();
void bufferWrite();
void runKernel();
void Release();

// main
int main(int argc, char** argv) {
	// OpenCL ����̽�, Ŀ�� �¾�
	CLInit();
	MaskAlloc();
	MultiColor();
	// OpenCL ������
	Release();
	system("pause");
	return 0;
}

void MultiColor()
{
	FILE * fp;

	//fp = fopen("test3.bmp", "rb");
	//fp = fopen("lenna_406.bmp", "rb");
	//fp = fopen("323test5.bmp", "rb");
	fp = fopen("input.bmp", "rb");

	if (fp == NULL)
	{
		printf("File Not Found!!\n");
		system("pause");
		exit(0);
	}
	// �������, ������� �о���δ�
	fread(&bfh, sizeof(bfh), 1, fp);
	fread(&bih, sizeof(bih), 1, fp);

	width = bih.biWidth;
	height = bih.biHeight;
	b_width = width * channel;
	b_height = height * channel;


	// BPL�� �����ֱ� ���ؼ� �ȼ��������� �޸𸮸� 4�� ����� ����
	bpl = (width * 3 + 3) / 4 * 4;
	b_bpl = (b_width * 3 + 3) / 4 * 4;

	// �е� �� ���
	pad = bpl - width * 3;
	b_pad = b_bpl - b_width * 3;

	// BPL�� ���� �޸� ������
	bpl_size = bpl * height;
	b_bpl_size = b_bpl * b_height;

	// ���� �̹��� �޸� ������
	pix_size = width * height * 3;
	b_pix_size = b_width * b_height * 3;

	printf("Image size : %d X %d\n", width, height);
	printf("Memory size : %d byte\n", bpl_size);
	printf("%d X %d Image size : %d X %d\n", channel, channel, b_width, b_height);
	printf("%d X %d Memory size : %d byte\n", channel, channel, b_bpl_size);

	// 24��Ʈ rgb bmp������ ���ȼ��� 3byte �̹Ƿ� 3�� �����ش�
	m_width = width * 3;
	b_m_width = b_width * 3;

	// ���� �̹��� ������ �Ҵ�
	pix = (unsigned char *)calloc(pix_size, sizeof(unsigned char));
	for (int i = 0; i < height; i++)
	{
		fread(pix + (i * m_width), sizeof(unsigned char), m_width, fp);
		fread(&trash, sizeof(BYTE), pad, fp);
	}

	// ���� �̹����� �� ���� �� ���� ������ �ݴ´�.
	fclose(fp);

	//sprintf(str, "test.bmp");
	//Fwrite(str);

	/*
	for(int i = 0; i < 1000; i++)
	{
		Draw();
	}
	*/

	// 5 X 5 �̹��� ������ �Ҵ�
	b_pix = (unsigned char *)calloc(b_pix_size, sizeof(unsigned char));

	QueryPerformanceFrequency(&tot_clockFreq);	// �ð��� �����ϱ����� �غ�

	QueryPerformanceCounter(&tot_beginClock); // CPU �ð����� ����
	for (int i = 0; i < b_pix_size; i++)
	{
		int px = i % m_width;
		int py = (i % (b_m_width * height)) / b_m_width;
		int ip = px + py * m_width;
		int mx = (i % b_m_width) / m_width;
		int my = i / (b_m_width * height);
		int im = mx + (4 - my) * 5; // bmp ������ ���������� �ȼ��� �����Ƿ� ����ũ �� ����� y��ǥ�� �������ش�.
		int rgb_m = (im * 3) + (ip % 3);
		short p, m, sum;

		p = pix[ip];
		m = mask[rgb_m];
		sum = p + m;
		if (sum >= 255)
			b_pix[i] = 255;
		else if (sum < 0)
			b_pix[i] = 0;
		else
			b_pix[i] = sum;
	}
	QueryPerformanceCounter(&tot_endClock); // CPU �ð����� ����
	total_Time_CPU = (double)(tot_endClock.QuadPart - tot_beginClock.QuadPart) / tot_clockFreq.QuadPart;

	//sprintf(str_Extend, "323test5_Extend_CPU.bmp");
	sprintf(str_Extend, "output_CPU.bmp");
	Fwrite_Extend(str_Extend);

	memset(b_pix, 0, sizeof(unsigned char) * b_pix_size);

	QueryPerformanceCounter(&tot_beginClock); // GPU �ð����� ����

	// ����̽� �� ���� ���� �� write								 
	bufferWrite();
	// Ŀ�� ����
	runKernel();

	QueryPerformanceCounter(&tot_endClock); // GPU �ð����� ����
	total_Time_GPU = (double)(tot_endClock.QuadPart - tot_beginClock.QuadPart) / tot_clockFreq.QuadPart;

	printf("CPU ����ð� : %.1lf(Sec)\nGPU ����ð� : %.1lf(Sec)\n", total_Time_CPU, total_Time_GPU);
	printf("CPU / GPU = %.1lf\n", total_Time_CPU / total_Time_GPU);

	//sprintf(str, "test_GPU.bmp");
	//sprintf(str_Extend, "test3_Extend.bmp");
	//sprintf(str_Extend, "lenna_406_Extend.bmp");
	//sprintf(str_Extend, "323test5_Extend_GPU.bmp");
	sprintf(str_Extend, "output_GPU.bmp");

	//sprintf(str_Extend, "output.bmp");

	//Fwrite(str);
	Fwrite_Extend(str_Extend);

	/*
	for (int i = 0; i < 1000; i++)
	{
		b_Draw();
	}
	*/

	free(b_pix);
	free(pix);
	
}
void MaskAlloc()
{
	char c;
	FILE * fp;
	fp = fopen("config_5.txt", "r");
	printf("\n");
	printf("--- 5 X 5 ����ũ �� ��� ---\n");
	for (int i = 0; i < 75; i++)
	{
		fscanf(fp, "%d%c", &mask[i], &c);
	}
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 15; j++)
		{
			printf("%3d. ", mask[j]);
		}
		printf("\n");
		printf("\n");
	}
	printf("\n");

	for (int i = 0; i < 75; i += 3)
	{
		c = mask[i + 2];
		mask[i + 2] = mask[i];
		mask[i] = c;
	}

	fclose(fp);
}
/*
void Fwrite(char * fn)
{
	FILE * fp2 = fopen(fn, "wb");
	fwrite(&bfh, sizeof(bfh), 1, fp2);
	fwrite(&bih, sizeof(bih), 1, fp2);

	for (int i = 0; i < height; i++)
	{
		fwrite(pix + (i * width), sizeof(unsigned char), width, fp2);
		fwrite(&trash, sizeof(BYTE), pad, fp2);
	}

	fclose(fp2);
}
*/
// ������ �ȼ����� bmp���Ϸ� ����.
void Fwrite_Extend(char * fn)
{
	FILE * fp2 = fopen(fn, "wb");
	b_bfh = bfh;
	b_bih = bih;
	b_bih.biWidth = b_width;
	b_bih.biHeight = b_height;
	b_bih.biSizeImage = b_bpl_size;
	b_bfh.bfSize = b_bih.biSizeImage + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	fwrite(&b_bfh, sizeof(bfh), 1, fp2);
	fwrite(&b_bih, sizeof(bih), 1, fp2);

	for (int i = 0; i < b_height; i++)
	{
		fwrite(b_pix + (i * b_m_width), sizeof(unsigned char), b_m_width, fp2);
		fwrite(&trash, sizeof(BYTE), b_pad, fp2);
	}

	fclose(fp2);
}
// ����� RGB ���� ȭ�鿡 ��½�Ų��.
/*
void Draw()
{
	HDC hdc;
	hdc = GetDC(NULL);

	SetDIBitsToDevice(hdc, 0, 0, bpl, height, 0, 0, 0, height,
		(unsigned char *)pix, (const BITMAPINFO *)&bih, DIB_RGB_COLORS);


	ReleaseDC(NULL, hdc);
}
void b_Draw()
{
	HDC hdc;
	hdc = GetDC(NULL);

	SetDIBitsToDevice(hdc, 0, 0, b_width, height * 2, 0, 0, 0, height * 2,
		(BYTE *)b_pix, (const BITMAPINFO *)&b_bih, DIB_RGB_COLORS);

	ReleaseDC(NULL, hdc);
}
*/
// kernel�� �о char pointer����
char* readSource(char* kernelPath) {

	cl_int status;
	FILE *fp;
	char *source;
	long int size;

	printf("Program file is: %s\n", kernelPath);

	fp = fopen(kernelPath, "rb");
	if (!fp) {
		printf("Could not open kernel file\n");
		exit(-1);
	}
	status = fseek(fp, 0, SEEK_END);
	if (status != 0) {
		printf("Error seeking to end of file\n");
		exit(-1);
	}
	size = ftell(fp);
	if (size < 0) {
		printf("Error getting file position\n");
		exit(-1);
	}

	rewind(fp);

	source = (char *)malloc(size + 1);

	int i;
	for (i = 0; i < size + 1; i++) {
		source[i] = '\0';
	}

	if (source == NULL) {
		printf("Error allocating space for the kernel source\n");
		exit(-1);
	}

	fread(source, 1, size, fp);
	source[size] = '\0';

	return source;
}

//����̽� init, Ŀ�� ����
void CLInit()
{
	int i, j;
	char * value;
	size_t valueSize;
	cl_uint platformCount;
	cl_platform_id * platforms;
	cl_uint deviceCount;
	cl_device_id * devices;
	cl_uint maxComputeUnits;

	// get all platforms
	clGetPlatformIDs(0, NULL, &platformCount);
	platforms = (cl_platform_id *)malloc(sizeof(cl_platform_id) * platformCount);
	clGetPlatformIDs(platformCount, platforms, NULL);

	for (i = 0; i < platformCount; i++) {

		// get all devices
		clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, 0, NULL, &deviceCount);
		devices = (cl_device_id *)malloc(sizeof(cl_device_id) * deviceCount);
		clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, deviceCount, devices, NULL);

		// for each device print critical attributes
		for (j = 0; j < deviceCount; j++) {

			// print device name
			clGetDeviceInfo(devices[j], CL_DEVICE_NAME, 0, NULL, &valueSize);
			value = (char *)malloc(valueSize);
			clGetDeviceInfo(devices[j], CL_DEVICE_NAME, valueSize, value, NULL);
			printf("platform %d. Device %d: %s\n", i + 1, j + 1, value);
			free(value);

			// print hardware device version
			clGetDeviceInfo(devices[j], CL_DEVICE_VERSION, 0, NULL, &valueSize);
			value = (char *)malloc(valueSize);
			clGetDeviceInfo(devices[j], CL_DEVICE_VERSION, valueSize, value, NULL);
			printf(" %d.%d Hardware version: %s\n", i + 1, 1, value);
			free(value);

			// print software driver version
			clGetDeviceInfo(devices[j], CL_DRIVER_VERSION, 0, NULL, &valueSize);
			value = (char *)malloc(valueSize);
			clGetDeviceInfo(devices[j], CL_DRIVER_VERSION, valueSize, value, NULL);
			printf(" %d.%d Software version: %s\n", i + 1, 2, value);
			free(value);

			// print c version supported by compiler for device
			clGetDeviceInfo(devices[j], CL_DEVICE_OPENCL_C_VERSION, 0, NULL, &valueSize);
			value = (char*)malloc(valueSize);
			clGetDeviceInfo(devices[j], CL_DEVICE_OPENCL_C_VERSION, valueSize, value, NULL);
			printf(" %d.%d OpenCL C version: %s\n", i + 1, 3, value);
			free(value);

			// print parallel compute units
			clGetDeviceInfo(devices[j], CL_DEVICE_MAX_COMPUTE_UNITS,
				sizeof(maxComputeUnits), &maxComputeUnits, NULL);
			printf(" %d.%d Parallel compute units: %d\n", i + 1, 4, maxComputeUnits);
		}
	}
	int platformNum;
	int deviceNum;
	printf("\n\nSELECT PLATFORM('1' ~ '%d') : ", platformCount);
	scanf("%d", &platformNum);
	printf("\n");
	printf("SELECT DEVICE('1' ~ '%d') : ", deviceCount);
	scanf("%d", &deviceNum);
	printf("\n");
	clGetDeviceIDs(platforms[platformNum - 1], CL_DEVICE_TYPE_ALL, deviceCount, devices, NULL);

	device = devices[deviceNum - 1];

	//create context
	context = clCreateContext(NULL, 1, &device, NULL, NULL, NULL);

	//create command queue
	queue = clCreateCommandQueue(context, device, 0, NULL);

	// �ؽ�Ʈ���Ϸκ��� ���α׷� �б�
	char * source = readSource("kernel.cl");

	// compile program
	program = clCreateProgramWithSource(context, 1,
		(const char **)&source, NULL, NULL);
	cl_int build_status;
	build_status = clBuildProgram(program, 1, &device, NULL, NULL,
		NULL);

	//Ŀ�� ������ ����
	simpleKernel = clCreateKernel(program, "simpleKernel", NULL);

}

//���ۻ��� �� write
void bufferWrite()
{
	// �޸� ���� ����
	d_pix = clCreateBuffer(context, CL_MEM_READ_ONLY,
		pix_size * sizeof(unsigned char), NULL, NULL);
	d_b_pix = clCreateBuffer(context, CL_MEM_WRITE_ONLY,
		b_pix_size * sizeof(unsigned char), NULL, NULL);
	d_mask = clCreateBuffer(context, CL_MEM_READ_ONLY,
		75 * sizeof(short), NULL, NULL);

	clEnqueueWriteBuffer(queue, d_pix, CL_TRUE, 0, sizeof(unsigned char) * pix_size,
		pix, 0, NULL, NULL);
	clEnqueueWriteBuffer(queue, d_mask, CL_TRUE, 0, sizeof(short) * 75,
		mask, 0, NULL, NULL);

}

void runKernel()
{
	int totalWorkItemsX = b_pix_size;
	int totalWorkItemsY = 1;

	size_t globalSize[2] = { totalWorkItemsX, totalWorkItemsY };
	//float *minVal, *maxVal;

	// Ŀ�� �Ű����� ���� 
	clSetKernelArg(simpleKernel, 0, sizeof(cl_mem), &d_pix);
	clSetKernelArg(simpleKernel, 1, sizeof(cl_mem), &d_b_pix);
	clSetKernelArg(simpleKernel, 2, sizeof(cl_mem), &d_mask);
	clSetKernelArg(simpleKernel, 3, sizeof(int), &m_width);
	clSetKernelArg(simpleKernel, 4, sizeof(int), &b_m_width);
	clSetKernelArg(simpleKernel, 5, sizeof(int), &height);

	clEnqueueNDRangeKernel(queue, simpleKernel, 2, NULL, globalSize,
		NULL, 0, NULL, NULL);
	// �Ϸ� ��� 
	clFinish(queue);

	clEnqueueReadBuffer(queue, d_b_pix, CL_TRUE, 0,
		b_pix_size * sizeof(unsigned char), b_pix, 0, NULL, NULL);

}
void Release()
{
	// ������
	clReleaseProgram(program);
	clReleaseCommandQueue(queue);
	clReleaseContext(context);
}